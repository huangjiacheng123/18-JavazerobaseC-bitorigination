package com.webtest.demo;

import org.testng.annotations.Test;
import com.webtest.core.BaseTest;

public class Demo extends BaseTest{
	@Test()
	public void test() {
		System.out.println("hello");
	}
}