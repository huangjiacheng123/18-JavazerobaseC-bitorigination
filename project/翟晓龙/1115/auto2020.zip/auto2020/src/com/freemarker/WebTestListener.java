package com.freemarker;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.testng.ITestContext;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;
import com.webtest.utils.ReadProperties;

//������
public class WebTestListener extends TestListenerAdapter {
	FreemarkerTemplateEngine ft = new FreemarkerTemplateEngine();

	public WebTestListener() {
		super();
	}

	public String writeResultToMailTemplate() {
		ITestNGMethod method[] = this.getAllTestMethods();
		List<ITestResult> failedList = this.getFailedTests();
		List<ITestResult> passedList = this.getPassedTests();
		List<ITestResult> failedList1 = new ArrayList<ITestResult>();
		List<ITestResult> passedList1 = new ArrayList<ITestResult>();
		for (int j = 0; j < failedList.size(); j++) {
			ITestResult tr = failedList.get(j);
			for (int i = 0; i < method.length; i++) {
				if (tr.getMethod().getMethodName().equals(method[i].getMethodName())) {
					if (method[i].getDescription() != null) {
						tr.setAttribute("name", method[i].getDescription());
					} else {
						tr.setAttribute("name", "");
					}
					break;
				}
			}
			failedList1.add(tr);
		}
		for (int j = 0; j < passedList.size(); j++) {
			ITestResult tr = (ITestResult) passedList.get(j);
			for (int i = 0; i < method.length; i++) {
				if (tr.getMethod().getMethodName().equals(method[i].getMethodName())) {
					if (method[i].getDescription() != null) {
						tr.setAttribute("name", method[i].getDescription());
					} else {
						tr.setAttribute("name", "");
					}
					break;
				}
			}
			passedList1.add(tr);
		}
		Map<String, Object> context = new HashMap<String, Object>();
		context.put("date", new Date());
		context.put("failedList", failedList1);
		context.put("passedList", passedList1);
		context.put("casesize", passedList.size() + failedList.size());
		context.put("failcasesize", failedList.size());
		context.put("passedcasesize", passedList.size());
		try {
			String content = ft.run(context);
			return content;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void onFinish(ITestContext testContext) {
		super.onFinish(testContext);
		String emailContent = this.writeResultToMailTemplate();
		String emailTitle;
		try {
			emailTitle = ReadProperties.getPropertyValue("mail_title") + "----" + this.getTime();
			String toMail = ReadProperties.getPropertyValue("to_mail");
			MailUtil.sendEmail(toMail, emailTitle, emailContent);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public String getTime() {
		Calendar c = Calendar.getInstance();
		SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd  hh:mm:ss");
		return f.format(c.getTime());
	}
}