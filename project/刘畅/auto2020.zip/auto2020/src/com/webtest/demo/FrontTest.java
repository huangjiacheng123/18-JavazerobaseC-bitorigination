package com.webtest.demo;

import org.testng.annotations.Test;

import com.webtest.core.BaseTest;

public class FrontTest extends BaseTest {
	@Test
	public void testLogin() {
		webtest.open("");
		webtest.type("","");
		
		
	}
	

}
